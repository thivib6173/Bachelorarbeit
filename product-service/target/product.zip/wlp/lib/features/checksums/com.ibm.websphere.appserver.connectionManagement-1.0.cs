#Tue Sep 29 21:58:38 CEST 2020
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionmanager_1.2-javadoc.zip=99a3b369cd802dc6b3fead13d634ba89
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=0aef8e5495604a2676482bb47fec432e
dev/api/ibm/com.ibm.websphere.appserver.api.connectionmanager_1.2.45.jar=936c20aa34a6e986166d43fecf5f8af4
