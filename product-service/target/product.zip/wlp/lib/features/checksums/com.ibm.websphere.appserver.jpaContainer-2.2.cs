#Tue Sep 29 21:58:38 CEST 2020
lib/com.ibm.ws.jpa.container_1.0.45.jar=f30caf1f2e272404d0b43e7f0a709450
lib/com.ibm.ws.jpa.container.thirdparty_1.0.45.jar=cb52a58feb1f4e3539baa80b2edf3022
lib/com.ibm.ws.jpa.container.v22_1.0.45.jar=7c2e8f0c96bab152c06d3f37b2a97afd
lib/features/com.ibm.websphere.appserver.jpaContainer-2.2.mf=d659760aa87507cd946ec52f0a214cae
