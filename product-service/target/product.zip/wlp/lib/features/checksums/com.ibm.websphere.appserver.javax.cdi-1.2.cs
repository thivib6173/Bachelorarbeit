#Tue Sep 29 21:58:44 CEST 2020
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.45.jar=02730b6f1bc3d925866ef895b0b36ea9
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=b6c08fe60360d6ce0897550aa631b819
