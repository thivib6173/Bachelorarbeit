#Tue Sep 29 21:58:45 CEST 2020
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=531a116958ae679b6b7f4ca353c538f3
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.45.jar=bdf4553adf21e0903562a1b6682fab7d
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=355081e09541840eba88d5de723bda32
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.45.jar=4b4de6f9a5eac8545500870741e41f1c
