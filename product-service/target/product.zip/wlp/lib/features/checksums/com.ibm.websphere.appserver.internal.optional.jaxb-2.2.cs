#Tue Sep 29 21:58:35 CEST 2020
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.45.jar=3dc1ec44a795212bf86de9909dbba6cd
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.45.jar=9512b79c0aa5b36bfc15a24eee6c07e9
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=76aabd1f3d8e5b328ad5e85a0f925ea5
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.45.jar=3dc0d132c9961185b9d63932bc84eaa5
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.45.jar=cd5ab01b419c220e0aaf78259f505aef
