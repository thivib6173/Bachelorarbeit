#Tue Sep 29 21:58:42 CEST 2020
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.1.mf=be2cc92bb72912e5b7333da1f658b600
lib/com.ibm.ws.jaxrs.2.0.security_1.0.45.jar=95547975845e8b8feab0679a8c50107b
