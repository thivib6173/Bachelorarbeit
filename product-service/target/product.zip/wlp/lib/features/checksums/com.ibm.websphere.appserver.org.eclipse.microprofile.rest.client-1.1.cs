#Tue Sep 29 21:58:44 CEST 2020
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.1_1.0.45.jar=f632be0dff2d12dd0ce6367c9892fd35
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.1.mf=d4c88ee949951c8845fb12835ebf0f8a
