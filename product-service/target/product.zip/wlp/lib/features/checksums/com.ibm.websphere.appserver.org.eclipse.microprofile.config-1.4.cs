#Tue Sep 29 21:58:33 CEST 2020
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.4_1.0.45.jar=c9e582efdecb95f8a28cc4cf0316aebc
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.4.mf=20d45819a115e0a759f160611fa4ae56
