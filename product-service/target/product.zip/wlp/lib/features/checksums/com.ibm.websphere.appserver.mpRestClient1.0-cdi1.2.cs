#Tue Sep 29 21:58:41 CEST 2020
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=27031831da117ebb8588dfc60a1468e1
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.45.jar=70cb4e851e35e14a6e226f0d9fe6f2a8
