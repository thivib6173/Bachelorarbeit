#Tue Sep 29 21:58:40 CEST 2020
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.45.jar=94f6e6bb0843bad6e09c7b301c31461a
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.1.mf=31f9e65c34e2cc0726a5195f798c25ea
