#Tue Sep 29 21:58:41 CEST 2020
lib/features/com.ibm.websphere.appserver.cdi2.0-transaction1.2.mf=31989bd48c9756379fcef3e5699b793c
lib/com.ibm.ws.cdi.transaction_1.0.45.jar=0802fa1e64982e438d105f080722b0b0
