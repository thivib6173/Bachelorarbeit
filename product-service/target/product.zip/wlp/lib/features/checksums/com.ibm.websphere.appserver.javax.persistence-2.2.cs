#Tue Sep 29 21:58:34 CEST 2020
lib/com.ibm.ws.javaee.persistence.api.2.2_1.0.45.jar=6857483c9a63f37ca0f270d489a701a5
dev/api/spec/com.ibm.websphere.javaee.persistence.2.2_1.0.45.jar=d885dc72fffdc56b255d69f28664fa29
lib/features/com.ibm.websphere.appserver.javax.persistence-2.2.mf=f8a3b40af7afd9049f503d50bdba3a52
