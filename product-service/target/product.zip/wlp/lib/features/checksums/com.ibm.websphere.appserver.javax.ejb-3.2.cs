#Tue Sep 29 21:58:34 CEST 2020
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.45.jar=7d5f515d935b14157d1b9ca5767ff8ca
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=1dec6ef5fb3a611577ef57b77e5a691b
