#Tue Sep 29 21:58:33 CEST 2020
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=c15141098237e434362e27e7391e09b9
lib/com.ibm.ws.injection_1.0.45.jar=ac4fa9364101a933afe10bc080815614
