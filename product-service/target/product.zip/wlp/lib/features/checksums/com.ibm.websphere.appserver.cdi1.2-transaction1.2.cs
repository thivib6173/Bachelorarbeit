#Tue Sep 29 21:58:46 CEST 2020
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=f9918392d915cda7352df0b523e4268c
lib/com.ibm.ws.cdi.transaction_1.0.45.jar=0802fa1e64982e438d105f080722b0b0
