#Tue Sep 29 21:58:39 CEST 2020
lib/features/com.ibm.websphere.appserver.javax.jaxrs-2.1.mf=a7dfe09c38013fb3c8ff9e694ca459e9
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.45.jar=3dc0d132c9961185b9d63932bc84eaa5
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.45.jar=cd5ab01b419c220e0aaf78259f505aef
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.1_1.0.45.jar=449b65654094a7c39e17d0b759a1a18a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=7b3f16c0baa3aa29bc007ee0f35b86f4
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.45.jar=9447c61be009f845b457705c2e5d5cb9
