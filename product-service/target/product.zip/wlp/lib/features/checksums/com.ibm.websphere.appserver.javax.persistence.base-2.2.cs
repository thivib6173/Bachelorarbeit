#Tue Sep 29 21:58:34 CEST 2020
lib/com.ibm.ws.javaee.persistence.2.2_1.0.45.jar=ec0c0a6098344adb477b105bf8360f8f
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.2.mf=2e1f53fa0edfa0f13e5834a01780d125
