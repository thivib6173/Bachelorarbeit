#Tue Sep 29 21:58:35 CEST 2020
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=ce81f9d089592dd773982c447516e2b2
lib/com.ibm.ws.transport.http_1.0.45.jar=3caaeafb86aadd50214360c1fb66f594
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_4.1.45.jar=98d23e841c18f0a54be932b98f8e4c3d
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_4.1-javadoc.zip=5c148cac63b1b0a81605617321679edf
