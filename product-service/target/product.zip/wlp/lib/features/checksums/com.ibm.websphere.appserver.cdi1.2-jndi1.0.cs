#Tue Sep 29 21:58:46 CEST 2020
lib/com.ibm.ws.cdi.jndi_1.0.45.jar=a80515370ff5a600c9b70e4aa2709726
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=b89afcc3f4f70c7745db8983099243ed
