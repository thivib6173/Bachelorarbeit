#Tue Sep 29 21:58:39 CEST 2020
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.4.mf=28416cd431d3f43185b515f9b8828e95
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.4_1.0.45.jar=6a6734789389bb44f8425ced1c9f7135
