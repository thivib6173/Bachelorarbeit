#Tue Sep 29 21:58:45 CEST 2020
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.45.jar=6e249916e73d724e232cd442ae1ab415
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.45.jar=f6bd4e78cc1be2b436276d08a7f11d8d
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=4e0a3f004ba5e580f6d10f07d3b47e38
