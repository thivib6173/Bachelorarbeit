#Tue Sep 29 21:58:45 CEST 2020
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.3_1.0.45.jar=ae6a0dead00504bf0aca7d1370234222
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.3.mf=c88800b4c154e86e5771bd71a37de2bf
