#Tue Sep 29 21:58:44 CEST 2020
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=19ced4a7fdf83e0083a20214e25314a7
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.45.jar=48a96e4d3d47258fb2ad75cfd5bc0e83
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.45.jar=3bc2091b951556b40f6889be008ec31f
