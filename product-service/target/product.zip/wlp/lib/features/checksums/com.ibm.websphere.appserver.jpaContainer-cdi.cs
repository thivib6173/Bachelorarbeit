#Tue Sep 29 21:58:41 CEST 2020
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.45.jar=b0ec101245ea1f8f04bc2c5a8d6b0c4d
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=d09fe4d8e1d3b3c4bcb5a3e4ba859251
