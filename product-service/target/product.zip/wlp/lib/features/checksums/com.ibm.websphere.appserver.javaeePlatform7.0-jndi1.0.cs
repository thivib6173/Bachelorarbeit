#Tue Sep 29 21:58:42 CEST 2020
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=0bceefe688eaf3f1bbe80c4fef61d4e5
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.45.jar=bee70735e3843c78eca2f73ddccb6d05
