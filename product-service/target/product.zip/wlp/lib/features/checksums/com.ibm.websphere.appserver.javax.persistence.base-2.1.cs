#Tue Sep 29 21:58:45 CEST 2020
lib/com.ibm.ws.javaee.persistence.2.1_1.0.45.jar=da8c99c997e452974e43e851259bfd6d
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=19eab1c5651c8e4ff03eba58fa05a2dc
