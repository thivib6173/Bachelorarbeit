#Tue Sep 29 21:58:38 CEST 2020
lib/features/com.ibm.websphere.appserver.jdbc-4.2.mf=ae35b8f1003ec6de39c7e6a80712da74
lib/com.ibm.ws.jdbc.4.2.feature_1.0.45.jar=51e38b5010056c5860ff89c6786f03da
lib/com.ibm.ws.jdbc.metatype_1.0.45.jar=dbda35085b74405e6b31c28002c440e7
