#Tue Sep 29 21:58:33 CEST 2020
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.45.jar=3a35d169c5b1add3c56d9ac5c5348a6d
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=c5f3c2ad897f84b5765ab165bf2f07fe
