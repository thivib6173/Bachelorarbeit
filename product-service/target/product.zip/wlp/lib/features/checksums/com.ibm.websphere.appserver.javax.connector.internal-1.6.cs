#Tue Sep 29 21:58:45 CEST 2020
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.45.jar=07e41c7648b588172154fedb181267c2
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=0592c8659cab87889f3c16b532101044
