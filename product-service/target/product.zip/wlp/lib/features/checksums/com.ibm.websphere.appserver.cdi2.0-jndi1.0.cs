#Tue Sep 29 21:58:41 CEST 2020
lib/features/com.ibm.websphere.appserver.cdi2.0-jndi1.0.mf=8dd149adc08a7e92ff6efd250eca6a2e
lib/com.ibm.ws.cdi.jndi_1.0.45.jar=a80515370ff5a600c9b70e4aa2709726
