#Tue Sep 29 21:58:38 CEST 2020
dev/api/spec/com.ibm.websphere.javaee.jsonb.1.0_1.0.45.jar=129af6a4bcb6079a5c063eb7b38144f1
lib/com.ibm.ws.org.eclipse.yasson.1.0_1.0.45.jar=7158fb72cea31a39c986fb9635a6ef0e
lib/features/com.ibm.websphere.appserver.jsonbImpl-1.0.1.mf=e9b2deb9443aa211b3c8c6b7f8afa273
