#Tue Sep 29 21:58:42 CEST 2020
lib/features/com.ibm.websphere.appserver.javaee-connectionManagement-1.0.mf=5335beb6b003ac35775c83c12720a96d
lib/com.ibm.ws.jca.cm_1.1.45.jar=32d2df33f87bcb5ef83ff3e1924f26fc
