#Tue Sep 29 21:58:33 CEST 2020
lib/features/com.ibm.websphere.appserver.javax.cdi-2.0.mf=b6415f6a7ada85b020bddf23e08fa2b6
dev/api/spec/com.ibm.websphere.javaee.cdi.2.0_1.0.45.jar=f5b27a0eab5656dbf79b225c734de3c1
