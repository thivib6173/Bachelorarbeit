#Tue Sep 29 21:58:34 CEST 2020
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=531a116958ae679b6b7f4ca353c538f3
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.45.jar=bdf4553adf21e0903562a1b6682fab7d
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.45.jar=2dbf0e4d9f58ee4c574244ff9b3f1d39
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=ce153a00382ac537bd213c6650f4a6d4
